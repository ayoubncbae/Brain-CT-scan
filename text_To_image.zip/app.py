# app.py
import os
import pickle
from text_preprocessing import TextImageRetrieval
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

def initialize_system(data_path, image_dir, force_recompute=False):
    """
    Initialize the retrieval system
    :param data_path: Path to CSV file
    :param image_dir: Directory with images
    :param force_recompute: Whether to recompute features
    :return: Initialized TextImageRetrieval object
    """
    retrieval_system = TextImageRetrieval(data_path, image_dir)
    
    if not force_recompute and os.path.exists('text_features.pkl') and os.path.exists('image_features.pkl'):
        print("Loading precomputed features...")
        retrieval_system.load_features()
    else:
        print("Computing features...")
        retrieval_system.load_data()
        retrieval_system.train_text_features()
        retrieval_system.extract_image_features()
        retrieval_system.save_text_features()
        print("Feature computation completed.")
    
    return retrieval_system

def display_results(results, image_dir):
    """Display search results with images and captions"""
    plt.figure(figsize=(15, 10))
    for i, result in enumerate(results, 1):
        img_path = os.path.join(image_dir, result['image'])
        img = mpimg.imread(img_path)
        
        plt.subplot(len(results), 1, i)
        plt.imshow(img)
        plt.title(f"Score: {result['score']:.3f}\nCaption: {result['caption']}")
        plt.axis('off')
    
    plt.tight_layout()
    plt.show()

def main():
    # Configuration
    DATA_PATH = '/home/ayoub/myenv/textToimageCode/megareport.csv'  # Update with your CSV path
    IMAGE_DIR = '/textToimageCode'       # Update with your image directory
    
    # Initialize system
    retrieval_system = initialize_system(DATA_PATH, IMAGE_DIR)
    
    # Example search
    while True:
        query = input("\nEnter your search query (or 'quit' to exit): ")
        if query.lower() == 'quit':
            break
        
        results = retrieval_system.text_to_image_search(query, top_k=3)
        print("\nSearch Results:")
        for i, result in enumerate(results, 1):
            print(f"{i}. Image: {result['image']} (Score: {result['score']:.3f})")
            print(f"   Caption: {result['caption']}\n")
        
        # Display images
        display_results(results, IMAGE_DIR)

if __name__ == "__main__":
    main()