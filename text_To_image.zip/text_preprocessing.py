# text_preprocessing.py
import string
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import pickle
import os
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import Model

class TextImageRetrieval:
    def __init__(self, data_path, image_dir):
        """
        Initialize the retrieval system
        :param data_path: Path to CSV file with captions and image names
        :param image_dir: Directory containing images
        """
        self.data_path = data_path
        self.image_dir = image_dir
        self.data = None
        self.tfidf_matrix = None
        self.vectorizer = None
        self.image_features = {}
        self.feature_model = self._create_feature_extractor()
        
    def _create_feature_extractor(self):
        """Create ResNet50 model for image feature extraction"""
        base_model = ResNet50(weights='imagenet')
        model = Model(inputs=base_model.input, 
                     outputs=base_model.get_layer('avg_pool').output)
        return model
    
    def load_data(self):
        """Load and preprocess the dataset"""
        self.data = pd.read_csv(self.data_path, encoding='ISO-8859-1')
        self.data['answer'] = self.data['answer'].apply(self._clean_text)
        
    def _clean_text(self, text):
        """Clean and preprocess text"""
        text = text.lower()
        text = text.translate(str.maketrans('', '', string.punctuation))
        return text
    
    def train_text_features(self):
        """Train TF-IDF vectorizer on the text data"""
        self.vectorizer = TfidfVectorizer(stop_words='english')
        self.tfidf_matrix = self.vectorizer.fit_transform(self.data['answer'])
        
    def extract_image_features(self):
        """Extract features for all images in the dataset"""
        unique_images = self.data['file'].unique()
        
        for img_file in unique_images:
            img_path = os.path.join(self.image_dir, img_file)
            try:
                img = image.load_img(img_path, target_size=(224, 224))
                x = image.img_to_array(img)
                x = np.expand_dims(x, axis=0)
                x = preprocess_input(x)
                features = self.feature_model.predict(x)
                self.image_features[img_file] = features.flatten()
            except Exception as e:
                print(f"Error processing {img_file}: {str(e)}")
        
        # Save features for later use
        with open('image_features.pkl', 'wb') as f:
            pickle.dump(self.image_features, f)
    
    def save_text_features(self):
        """Save text features for later use"""
        with open('text_features.pkl', 'wb') as f:
            pickle.dump({
                'vectorizer': self.vectorizer,
                'tfidf_matrix': self.tfidf_matrix,
                'image_mapping': self.data[['file', 'answer']].to_dict('records')
            }, f)
    
    def load_features(self):
        """Load precomputed features"""
        with open('text_features.pkl', 'rb') as f:
            text_data = pickle.load(f)
            self.vectorizer = text_data['vectorizer']
            self.tfidf_matrix = text_data['tfidf_matrix']
            self.data = pd.DataFrame(text_data['image_mapping'])
        
        with open('image_features.pkl', 'rb') as f:
            self.image_features = pickle.load(f)
    
    def text_to_image_search(self, query, top_k=5):
        """
        Search for images based on text query
        :param query: Text query describing the image
        :param top_k: Number of results to return
        :return: List of matching image files and their similarity scores
        """
        # Clean and vectorize the query
        clean_query = self._clean_text(query)
        query_vec = self.vectorizer.transform([clean_query])
        
        # Compute similarity between query and all captions
        similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
        
        # Get top K matches
        top_indices = similarities.argsort()[-top_k:][::-1]
        results = []
        
        for idx in top_indices:
            img_file = self.data.iloc[idx]['file']
            score = similarities[idx]
            caption = self.data.iloc[idx]['answer']
            results.append({
                'image': img_file,
                'score': score,
                'caption': caption
            })
        
        return results
    
    def get_image_features(self, image_file):
        """Get features for a specific image"""
        return self.image_features.get(image_file, None)